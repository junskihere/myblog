var require = meteorInstall({"lib":{"collections":{"index.js":["./user","./posts",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/index.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
exports.Posts = exports.PostSchema = exports.User = undefined;                                    //
                                                                                                  //
var _user = require('./user');                                                                    // 1
                                                                                                  //
var _user2 = _interopRequireDefault(_user);                                                       //
                                                                                                  //
var _posts = require('./posts');                                                                  // 2
                                                                                                  //
var _posts2 = _interopRequireDefault(_posts);                                                     //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
exports.User = _user2['default'];                                                                 //
exports.PostSchema = _posts2['default'];                                                          //
exports.Posts = _posts.Posts;                                                                     //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"posts.js":["meteor/jagi:astronomy","meteor/mongo",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/posts.js                                                                       //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
    value: true                                                                                   //
});                                                                                               //
exports.Posts = undefined;                                                                        //
                                                                                                  //
var _jagiAstronomy = require('meteor/jagi:astronomy');                                            // 1
                                                                                                  //
var _mongo = require('meteor/mongo');                                                             // 2
                                                                                                  //
var Posts = exports.Posts = new _mongo.Mongo.Collection("posts");                                 // 4
                                                                                                  //
var PostSchema = _jagiAstronomy.Class.create({                                                    // 6
    name: "PostSchema",                                                                           // 7
    collection: Posts,                                                                            // 8
    fields: {                                                                                     // 9
        title: {                                                                                  // 10
            type: String,                                                                         // 11
            validators: [{                                                                        // 12
                type: 'minLength',                                                                // 13
                param: 10,                                                                        // 14
                message: 'The title is too short! (min of 10 characters)'                         // 15
            }]                                                                                    // 12
        },                                                                                        // 10
        user_id: String,                                                                          // 18
        body: {                                                                                   // 19
            type: String,                                                                         // 20
            validators: [{                                                                        // 21
                type: 'minLength',                                                                // 22
                param: 100,                                                                       // 23
                message: 'The body is too short! (min of 100 characters)'                         // 24
            }]                                                                                    // 21
        },                                                                                        // 19
        description: {                                                                            // 27
            type: String,                                                                         // 28
            validators: [{                                                                        // 29
                type: 'minLength',                                                                // 30
                param: 20,                                                                        // 31
                message: 'The description is too short! (min of 20 characters)'                   // 32
            }]                                                                                    // 29
        },                                                                                        // 27
        type: String,                                                                             // 35
        images: Object,                                                                           // 36
        createdAt: Date                                                                           // 37
    }                                                                                             // 9
});                                                                                               // 6
                                                                                                  //
exports['default'] = PostSchema;                                                                  //
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"user.js":["meteor/jagi:astronomy","meteor/accounts-base","meteor/meteor",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// lib/collections/user.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
    value: true                                                                                   //
});                                                                                               //
                                                                                                  //
var _jagiAstronomy = require('meteor/jagi:astronomy');                                            // 1
                                                                                                  //
var _accountsBase = require('meteor/accounts-base');                                              // 2
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 3
                                                                                                  //
_meteor.Meteor.startup(function () {                                                              // 4
    if (_meteor.Meteor.isServer) {                                                                // 5
        _accountsBase.Accounts.onCreateUser(function (options, user) {                            // 6
            user.firstname = options.firstname;                                                   // 7
            user.lastname = options.lastname;                                                     // 8
            return user;                                                                          // 9
        });                                                                                       // 10
    }                                                                                             // 11
});                                                                                               // 12
                                                                                                  //
var User = _jagiAstronomy.Class.create({                                                          // 16
    name: "User",                                                                                 // 17
    collection: _meteor.Meteor.users,                                                             // 18
    fields: {                                                                                     // 19
        firstname: String,                                                                        // 20
        lastname: String,                                                                         // 21
        emails: [Object],                                                                         // 22
        password: String,                                                                         // 23
        createdAt: Date                                                                           // 24
    },                                                                                            // 19
    events: {                                                                                     // 26
        beforeInsert: function beforeInsert(e) {                                                  // 27
                                                                                                  //
            if (_meteor.Meteor.isServer) {                                                        // 29
                e.preventDefault();                                                               // 30
                _accountsBase.Accounts.createUser({                                               // 31
                    firstname: e.currentTarget.firstname,                                         // 32
                    lastname: e.currentTarget.lastname,                                           // 33
                    email: e.currentTarget.email,                                                 // 34
                    password: e.currentTarget.password,                                           // 35
                    createdAt: new Date()                                                         // 36
                });                                                                               // 31
            }                                                                                     // 38
        }                                                                                         // 39
    }                                                                                             // 26
                                                                                                  //
});                                                                                               // 16
                                                                                                  //
// const User = Class.create({                                                                    //
//     name : "User",                                                                             //
//     collection : Meteor.users,                                                                 //
//     fields : {                                                                                 //
//       firstname : String,                                                                      //
//       lastname : String,                                                                       //
//       emails : {                                                                               //
//           type : [Object],                                                                     //
//           optional : true,                                                                     //
//       },                                                                                       //
//       password : String,                                                                       //
//       createdAt : Date,                                                                        //
//     },                                                                                         //
//     events : {                                                                                 //
//         afterInsert(e){                                                                        //
//                 Accounts.createUser({                                                          //
//                       emails: e.currentTarget.email,                                           //
//                       password : e.currentTarget.password,                                     //
//                   });                                                                          //
//      },                                                                                        //
//     }                                                                                          //
//                                                                                                //
// });                                                                                            //
                                                                                                  //
exports['default'] = User;                                                                        //
////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"methods":{"accounts.js":["/lib/collections/user.js","meteor/meteor",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/accounts.js                                                                     //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 4
    'accounts.register': function accountsRegister(data) {                                        // 5
      var user = new _user2['default']();                                                         // 6
      user.firstname = data.firstName;                                                            // 7
      user.lastname = data.lastName;                                                              // 8
      user.password = data.password;                                                              // 9
      user.email = data.email;                                                                    // 10
      user.createdAt = new Date();                                                                // 11
      // user.data = data;                                                                        //
      user.save();                                                                                // 13
    }                                                                                             // 14
  });                                                                                             // 4
};                                                                                                // 16
                                                                                                  //
var _user = require('/lib/collections/user.js');                                                  // 1
                                                                                                  //
var _user2 = _interopRequireDefault(_user);                                                       //
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"index.js":["./accounts.js","./upload_to_cloudinary.js","./posts",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/index.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _accounts2['default'])();                                                                   // 6
  (0, _upload_to_cloudinary2['default'])();                                                       // 7
  (0, _posts2['default'])();                                                                      // 8
};                                                                                                // 9
                                                                                                  //
var _accounts = require('./accounts.js');                                                         // 1
                                                                                                  //
var _accounts2 = _interopRequireDefault(_accounts);                                               //
                                                                                                  //
var _upload_to_cloudinary = require('./upload_to_cloudinary.js');                                 // 2
                                                                                                  //
var _upload_to_cloudinary2 = _interopRequireDefault(_upload_to_cloudinary);                       //
                                                                                                  //
var _posts = require('./posts');                                                                  // 3
                                                                                                  //
var _posts2 = _interopRequireDefault(_posts);                                                     //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"posts.js":["/lib/collections","meteor/meteor",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/posts.js                                                                        //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 6
    'getLatestPosts': function getLatestPosts() {                                                 // 7
      return _collections.Posts.find({}, { $sort: { createdAt: -1 } }).fetch();                   // 8
    }                                                                                             // 9
  });                                                                                             // 6
};                                                                                                // 11
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"upload_to_cloudinary.js":["meteor/meteor","cloudinary","datauri","/lib/collections/posts.js","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/methods/upload_to_cloudinary.js                                                         //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
"use strict";                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports["default"] = function () {                                                                //
  _meteor.Meteor.methods({                                                                        // 9
    'createPost': function createPost(formData) {                                                 // 10
      (0, _check.check)(formData, Object);                                                        // 11
                                                                                                  //
      formData.body = formData.body.replace('<div class="quill-contents ql-container ql-snow"><br></div></div><div class="ql-tooltip ql-link-tooltip" style="left: -10000px; top: 83px;"><span class="title">Visit URL:&nbsp;</span> <a href="javascript:;" class="url" target="_blank">javascript:;</a> <input class="input" type="text"> <span>&nbsp;-&nbsp;</span> <a href="javascript:;" class="change">Change</a> <a href="javascript:;" class="remove">Remove</a> <a href="javascript:;" class="done">Done</a></div><div class="ql-tooltip ql-image-tooltip" style="left: -10000px;"><input class="input" type="textbox"> <div class="preview"> <span>Preview</span> </div> <a href="javascript:;" class="cancel">Cancel</a> <a href="javascript:;" class="insert">Insert</a></div><div class="ql-paste-manager" contenteditable="true" tabindex="-1"></div></div>', "");
      formData.body = formData.body.replace('<div class="ql-tooltip ql-link-tooltip" style="left: -10000px;"><span class="title">Visit URL:&nbsp;</span> <a href="#" class="url" target="_blank"></a> <input class="input" type="text"> <span>&nbsp;-&nbsp;</span> <a href="javascript:;" class="change">Change</a> <a href="javascript:;" class="remove">Remove</a> <a href="javascript:;" class="done">Done</a></div><div class="ql-tooltip ql-image-tooltip" style="left: -10000px;"><input class="input" type="textbox"> <div class="preview"> <span>Preview</span> </div> <a href="javascript:;" class="cancel">Cancel</a> <a href="javascript:;" class="insert">Insert</a></div><div class="ql-paste-manager" contenteditable="true" tabindex="-1"></div></div>', "");
      return new Promise(function (resolve) {                                                     // 15
        uploadImage(formData.images).then(function (result) {                                     // 16
          var post = new _posts2["default"]();                                                    // 17
          post.title = formData.title;                                                            // 18
          post.body = formData.body;                                                              // 19
          post.user_id = _meteor.Meteor.userId();                                                 // 20
          post.images = result;                                                                   // 21
          post.type = formData.type;                                                              // 22
          post.description = formData.description;                                                // 23
          post.createdAt = new Date();                                                            // 24
          post.save(function (err) {                                                              // 25
            if (err) {                                                                            // 26
              var errors = err.details[0];                                                        // 27
              throw new Error(errors.message);                                                    // 28
            }                                                                                     // 29
            resolve("Created Transaction");                                                       // 30
          });                                                                                     // 31
        });                                                                                       // 32
      });                                                                                         // 33
    },                                                                                            // 34
    'updatePost': function updatePost(formData) {                                                 // 35
      (0, _check.check)(formData, Object);                                                        // 36
      formData.body = formData.body.replace('<div class="quill-contents ql-container ql-snow"><br></div></div><div class="ql-tooltip ql-link-tooltip" style="left: -10000px; top: 83px;"><span class="title">Visit URL:&nbsp;</span> <a href="javascript:;" class="url" target="_blank">javascript:;</a> <input class="input" type="text"> <span>&nbsp;-&nbsp;</span> <a href="javascript:;" class="change">Change</a> <a href="javascript:;" class="remove">Remove</a> <a href="javascript:;" class="done">Done</a></div><div class="ql-tooltip ql-image-tooltip" style="left: -10000px;"><input class="input" type="textbox"> <div class="preview"> <span>Preview</span> </div> <a href="javascript:;" class="cancel">Cancel</a> <a href="javascript:;" class="insert">Insert</a></div><div class="ql-paste-manager" contenteditable="true" tabindex="-1"></div></div>', "");
      formData.body = formData.body.replace('<div class="ql-tooltip ql-link-tooltip" style="left: -10000px;"><span class="title">Visit URL:&nbsp;</span> <a href="#" class="url" target="_blank"></a> <input class="input" type="text"> <span>&nbsp;-&nbsp;</span> <a href="javascript:;" class="change">Change</a> <a href="javascript:;" class="remove">Remove</a> <a href="javascript:;" class="done">Done</a></div><div class="ql-tooltip ql-image-tooltip" style="left: -10000px;"><input class="input" type="textbox"> <div class="preview"> <span>Preview</span> </div> <a href="javascript:;" class="cancel">Cancel</a> <a href="javascript:;" class="insert">Insert</a></div><div class="ql-paste-manager" contenteditable="true" tabindex="-1"></div></div>', "");
      if (formData.images) {                                                                      // 39
        return new Promise(function (resolve) {                                                   // 40
          uploadImage(formData.images).then(function (result) {                                   // 41
            var post = _posts2["default"].findOne({ _id: formData.posts_id });                    // 42
            post._id = formData.posts_id;                                                         // 43
            post.title = formData.title;                                                          // 44
            post.body = formData.body;                                                            // 45
            post.user_id = _meteor.Meteor.userId();                                               // 46
            post.images = result;                                                                 // 47
            post.type = formData.type;                                                            // 48
            post.description = formData.description;                                              // 49
            post.save(function (err) {                                                            // 50
              if (err) {                                                                          // 51
                var errors = err.details[0];                                                      // 52
                throw new _meteor.Meteor.Error(errors.message);                                   // 53
              }                                                                                   // 54
              resolve("Created Transaction");                                                     // 55
            });                                                                                   // 56
          });                                                                                     // 57
        });                                                                                       // 58
      } else {                                                                                    // 59
        var post = _posts2["default"].findOne({ _id: formData.posts_id });                        // 60
        post._id = formData.posts_id;                                                             // 61
        post.title = formData.title;                                                              // 62
        post.body = formData.body;                                                                // 63
        post.user_id = _meteor.Meteor.userId();                                                   // 64
        post.type = formData.type;                                                                // 65
        post.description = formData.description;                                                  // 66
        post.save(function (err) {                                                                // 67
          if (err) {                                                                              // 68
            var errors = err.details[0];                                                          // 69
            throw new _meteor.Meteor.Error(errors.message);                                       // 70
          }                                                                                       // 71
          return "Created Transaction";                                                           // 72
        });                                                                                       // 73
      }                                                                                           // 74
    }                                                                                             // 75
  });                                                                                             // 9
};                                                                                                // 77
                                                                                                  //
var _meteor = require("meteor/meteor");                                                           // 1
                                                                                                  //
var _cloudinary = require("cloudinary");                                                          // 2
                                                                                                  //
var _cloudinary2 = _interopRequireDefault(_cloudinary);                                           //
                                                                                                  //
var _datauri = require("datauri");                                                                // 3
                                                                                                  //
var _datauri2 = _interopRequireDefault(_datauri);                                                 //
                                                                                                  //
var _posts = require("/lib/collections/posts.js");                                                // 4
                                                                                                  //
var _posts2 = _interopRequireDefault(_posts);                                                     //
                                                                                                  //
var _check = require("meteor/check");                                                             // 5
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
                                                                                                  //
var uploadImage = function uploadImage(images) {                                                  // 80
  return new Promise(function (resolve) {                                                         // 81
    _cloudinary2["default"].config({                                                              // 82
      cloud_name: 'dnebqjbyh',                                                                    // 83
      api_key: '264784665157316',                                                                 // 84
      api_secret: 'DBgUmUAaTYoZ27AokZJ1Gs_QY0c'                                                   // 85
    });                                                                                           // 82
    var dUri = new _datauri2["default"]();                                                        // 87
    var raw = new Buffer(images);                                                                 // 88
    dUri.format('.png', raw);                                                                     // 89
    _cloudinary2["default"].uploader.upload(dUri.content, function (result) {                     // 90
      resolve(result);                                                                            // 91
    });                                                                                           // 92
  });                                                                                             // 94
};                                                                                                // 95
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"publications":{"index.js":["./posts","./users",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/index.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  (0, _posts2['default'])();                                                                      // 5
  (0, _users2['default'])();                                                                      // 6
};                                                                                                // 7
                                                                                                  //
var _posts = require('./posts');                                                                  // 1
                                                                                                  //
var _posts2 = _interopRequireDefault(_posts);                                                     //
                                                                                                  //
var _users = require('./users');                                                                  // 2
                                                                                                  //
var _users2 = _interopRequireDefault(_users);                                                     //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"posts.js":["/lib/collections","meteor/meteor","meteor/check","/lib/collections/posts.js",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/posts.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.publish('posts', function () {                                                   // 7
    return _posts2['default'].find();                                                             // 8
  });                                                                                             // 9
                                                                                                  //
  _meteor.Meteor.publish('post.view', function (postId) {                                         // 11
    return _posts2['default'].find({ _id: postId });                                              // 12
  });                                                                                             // 13
};                                                                                                // 14
                                                                                                  //
var _collections = require('/lib/collections');                                                   // 1
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
                                                                                                  //
var _posts = require('/lib/collections/posts.js');                                                // 4
                                                                                                  //
var _posts2 = _interopRequireDefault(_posts);                                                     //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}],"users.js":["/lib/collections/user.js","meteor/meteor","meteor/check",function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/publications/users.js                                                                   //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
Object.defineProperty(exports, "__esModule", {                                                    //
  value: true                                                                                     //
});                                                                                               //
                                                                                                  //
exports['default'] = function () {                                                                //
  _meteor.Meteor.publish('users.current', function () {                                           // 6
    return _user2['default'].find(this.userId);                                                   // 7
  });                                                                                             // 8
};                                                                                                // 9
                                                                                                  //
var _user = require('/lib/collections/user.js');                                                  // 1
                                                                                                  //
var _user2 = _interopRequireDefault(_user);                                                       //
                                                                                                  //
var _meteor = require('meteor/meteor');                                                           // 2
                                                                                                  //
var _check = require('meteor/check');                                                             // 3
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"main.js":["./publications","./methods",function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                //
// server/main.js                                                                                 //
//                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                  //
'use strict';                                                                                     //
                                                                                                  //
var _publications = require('./publications');                                                    // 1
                                                                                                  //
var _publications2 = _interopRequireDefault(_publications);                                       //
                                                                                                  //
var _methods = require('./methods');                                                              // 2
                                                                                                  //
var _methods2 = _interopRequireDefault(_methods);                                                 //
                                                                                                  //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
                                                                                                  //
(0, _publications2['default'])();                                                                 // 4
(0, _methods2['default'])();                                                                      // 5
////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".jsx"]});
require("./lib/collections/index.js");
require("./lib/collections/posts.js");
require("./lib/collections/user.js");
require("./server/methods/accounts.js");
require("./server/methods/index.js");
require("./server/methods/posts.js");
require("./server/methods/upload_to_cloudinary.js");
require("./server/publications/index.js");
require("./server/publications/posts.js");
require("./server/publications/users.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
